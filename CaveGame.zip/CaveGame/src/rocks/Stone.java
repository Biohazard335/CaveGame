package rocks;

import collision.shapes.Point;

public class Stone extends Rock{
	public Stone(Point origin) {
		super(origin, 7,1, 1,-1,-1,"Stone");
	}
}